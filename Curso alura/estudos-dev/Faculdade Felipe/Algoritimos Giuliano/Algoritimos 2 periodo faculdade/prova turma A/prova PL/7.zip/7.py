# É o algoritimo Bubble Sort.
# Sua principal caracteristica é sua troca de dois em dois elementos, porem acaba sendo um pouco mais lento comparado com os outros


